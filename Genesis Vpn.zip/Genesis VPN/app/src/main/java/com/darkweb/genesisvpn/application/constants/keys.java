package com.darkweb.genesisvpn.application.constants;

public class keys {
    public static String app_initialized_key = "app_initialized";
    public static String ads_disabled = "ads_disabled";
}
