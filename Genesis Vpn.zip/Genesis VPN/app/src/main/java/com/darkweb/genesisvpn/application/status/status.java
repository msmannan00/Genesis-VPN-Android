package com.darkweb.genesisvpn.application.status;

import com.darkweb.genesisvpn.application.constants.enums;

public class status
{
    public static enums.connection_status connection_status = enums.connection_status.no_status;
    public static enums.connection_servers servers_loaded = enums.connection_servers.not_loaded;
    public static enums.app_status app_status = enums.app_status.resumed;
}
