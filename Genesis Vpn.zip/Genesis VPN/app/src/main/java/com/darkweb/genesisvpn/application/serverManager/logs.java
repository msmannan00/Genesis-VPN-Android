package com.darkweb.genesisvpn.application.serverManager;

import android.util.Log;

public class logs {

    public static void log(String message)
    {
        Log.i("Log",message);
    }

}
